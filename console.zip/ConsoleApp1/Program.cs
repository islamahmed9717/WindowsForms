﻿using System;
using System.Configuration;
namespace pro
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("islam ahmed mohamed ali");


        }
    }
}